import random

# Function to generate a random prime number
def generate_prime(lower=50, upper=2000):
    while True:
        num = random.randint(lower, upper)
        if is_prime(num):
            return num

# Function to check if a number is prime
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

# Function to compute the greatest common divisor (gcd)
def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# Function to compute the modular inverse using Extended Euclidean Algorithm
def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        m, a = a % m, m
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += m0
    return x1

# Step 1: Generate two random prime numbers p and q
p = generate_prime()
q = generate_prime()
while p == q:  # Ensure p and q are distinct
    q = generate_prime()

# Step 2: Calculate n and ϕ(n)
n = p * q
phi = (p - 1) * (q - 1)

# Public key e
e = 3
while e < phi and gcd(e, phi) != 1:  # Ensure e and phi(n) are coprime
    e += 1

# Step 3: Calculate private key d (modular multiplicative inverse of e)
d = mod_inverse(e, phi)
print("RSA Implementation\n")
# Display RSA parameters
print(f"Generated primes: p={p}, q={q}")
print(f"n = {n}, ϕ(n) = {phi}")
print(f"Public key: (e={e}, n={n})")
print(f"Private key: (d={d}, n={n})")

# Step 4: Encrypt the message
def encrypt(message, e, n):
    return [pow(m, e, n) for m in message]

# Step 5: Decrypt the message
def decrypt(ciphertext, d, n):
    return [pow(c, d, n) for c in ciphertext]

# Input a numerical message
message = input("Enter a message as a sequence of numbers(space-separated): ")
message = list(map(int, message.split()))

# Encrypt the message
ciphertext = encrypt(message, e, n)
print(f"Encrypted message: {ciphertext}")

# Decrypt the message
decrypted_message = decrypt(ciphertext, d, n)
print(f"Decrypted message: {decrypted_message}")
