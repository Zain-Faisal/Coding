def vigenere_encrypt(plaintext, keyword):
    """Encrypt plaintext using the Vigenère cipher."""
    keyword = keyword.upper()
    ciphertext = ""
    
    for i, char in enumerate(plaintext):
        if char.isalpha():
            shift = ord(keyword[i % len(keyword)]) - ord('A')
            base = ord('A') if char.isupper() else ord('a')
            ciphertext += chr((ord(char) - base + shift) % 26 + base)
        else:
            ciphertext += char
    return ciphertext


def vigenere_decrypt(ciphertext, keyword):
    """Decrypt ciphertext using the Vigenère cipher."""
    keyword = keyword.upper()
    plaintext = ""
    
    for i, char in enumerate(ciphertext):
        if char.isalpha():
            shift = ord(keyword[i % len(keyword)]) - ord('A')
            base = ord('A') if char.isupper() else ord('a')
            plaintext += chr((ord(char) - base - shift + 26) % 26 + base)
        else:
            plaintext += char
    return plaintext

print("Vigenère Cipher\n")
# Input plaintext and keyword
plaintext = input("Enter the plaintext message: ")
keyword = input("Enter the keyword: ")

# Encrypt and decrypt
ciphertext = vigenere_encrypt(plaintext, keyword)
print(f"Encrypted message: {ciphertext}")

decrypted_message = vigenere_decrypt(ciphertext, keyword)
print(f"Decrypted message: {decrypted_message}")
