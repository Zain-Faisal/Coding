def caesar_encrypt(plaintext, shift):
    """
    Encrypts the plaintext using the Caesar cipher with the given shift value.
    """
    ciphertext = ""
    for char in plaintext:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            ciphertext += chr((ord(char) - shift_base + shift) % 26 + shift_base)
        else:
            ciphertext += char  # Non-alphabetic characters remain unchanged
    return ciphertext


def caesar_decrypt(ciphertext, shift):
    """
    Decrypts the ciphertext using the Caesar cipher with the given shift value.
    """
    return caesar_encrypt(ciphertext, -shift)


def brute_force_caesar(ciphertext):
    """
    Performs a brute-force attack on the Caesar cipher.
    Tries all possible shift values to decrypt the ciphertext.
    """
    for shift in range(26):
        decrypted_message = caesar_decrypt(ciphertext, shift)
        print(f"Shift {shift}: {decrypted_message}")
print("Caesar Cipher\n")

# Input the message and shift value
message = input("Enter the message: ")
shift = int(input("Enter the shift value: "))

# Encrypt the message
encrypted_message = caesar_encrypt(message, shift)
print(f"\nEncrypted message: {encrypted_message}")

# Decrypt the message
decrypted_message = caesar_decrypt(encrypted_message, shift)
print(f"Decrypted message: {decrypted_message}")
text = "EOXH MHDQV"
# Perform brute-force attack
print("\nBrute-force results on: ",text)

brute_force_caesar(text)
