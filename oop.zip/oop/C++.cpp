// //     #include<iostream>
// //  using namespace std;
// //  class Area{
// //     public:
// //     int length;
// //     int width;
// //    Area(){
// //     length=20;
// //     width=15;
// //     cout<<"Welcome to Area Class"<<endl;
// //    }
// //  Area(Area &a){
// //     length=a.length+5;
// //     width=a.width+5; 
// //  }
// //  Area(int length,int width){
// //     this->length=length;
// //     this->width=width;

// //  }
// //  Area(double length,double width){
// //     this->length=length;
// //     this->width=width;
// //  }
// //  void calculate(){
// //     cout<<"Area : "<<length*width<<endl;
// //  }
// //  };
// // int main(){
// //     Area area;
// //     area.calculate();
// //     Area a1(area);
// //     a1.calculate();
// //     Area a2(34.6,45.6);
// //     a2.calculate();
// // }



// // #include<iostream>
// // using namespace std;
// // class AS{
// // public:
// // void virtual x()=0;




// // };

// // int main(){
// //    AS *u;

// // }


// // Stack implementation in C++


// // #include <iostream>

// // using namespace std;

// // #define MAX 10
// // int size ;

// // // Creating a stack
// // struct st {
// //   int items[MAX];
// //   int top;
// // };
 

// // void createEmptyStack(st *s) {
// //   s->top = -1;
// // }

// // // Check if the stack is full
// // int isfull(st *s) {
// //   if (s->top == MAX - 1)
// //     return 1;
// //   else
// //     return 0;
// // }

// // // Check if the stack is empty
// // int isempty(st *s) {
// //   if (s->top == -1)
// //     return 1;
// //   else
// //     return 0;
// // }

// // // Add elements into stack
// // void push(st *s, int newitem) {
// //   if (isfull(s)) {
// //     cout << "STACK FULL";
// //   } else {
// //     s->top++;
// //     s->items[s->top] = newitem;
// //   }
// //   size++;
// // }

// // // Remove element from stack
// // void pop(st *s) {
// //   if (isempty(s)) {
// //     cout << "\n STACK EMPTY \n";
// //   } else {
// //     cout << "Item popped= " << s->items[s->top];
// //     s->top--;
// //   }
// //   size--;
// //   cout << endl;
// // }

// // // Print elements of stack
// // void printStack(st *s) {
// //   cout<<"Stack :"<<endl;
// //   for (int i = 0; i < size; i++) {
// //     cout << s->items[i] << " ";
// //   }
// //   cout << endl;
// // }

// // // Driver code
// // int main() {
// //   int ch;
// //   st *s = (st *)malloc(sizeof(st));

// //   createEmptyStack(s);

// //   push(s, 1);
// //   push(s, 2);
// //   push(s, 3);
// //   push(s, 4);

// //   printStack(s);

// //   pop(s);

// //   cout << "\nAfter popping out\n";
// //   printStack(s);
// // }

// // Queue implementation in C++

// #include <iostream>
// #define SIZE 5

// using namespace std;

// class Queue {
//    private:
//   int items[SIZE], front, rear;

//    public:
//   Queue() {
//     front = -1;
//     rear = -1;
//   }

//   bool isFull() {
//     if (front == 0 && rear == SIZE - 1) {
//       return true;
//     }
//     return false;
//   }

// <<<<<<<<<<<<<  ✨ Codeiu
// m AI Suggestion  >>>>>>>>>>>>>>
// +  /**
// +   * A description of the entire C++ function.
// +   *
// +   * @param paramName description of parameter
// +   *
// +   * @return description of return value
// +   *
// +   * @throws ErrorType description of error
// +   */
// <<<<<  bot-34104516-66be-4bb8-800b-d0b26ef4a995  >>>>>
//   bool isEmpty() {
//     if (front == -1)
//       return true;
//     else
//       return false;
//   }

//   void enQueue(int element) {
//     if (isFull()) {
//       cout << "Queue is full";
//     } else {
//       if (front == -1) 
//       front = 0;
//       rear++;
//       items[rear] = element;
//       cout << endl;
//          << "Inserted " << element << endl;
//     }
//   }

//   int deQueue() {
//     int element;
//     if (isEmpty()) {
//       cout << "Queue is empty" << endl;
//       return (-1);
//     } else {
//       element = items[front];
//       if (front >= rear) {
//         front = -1;
//         rear = -1;
//       } /* Q has only one element, so we reset the queue after deleting it. */
//       else {
//         front++;
//       }
//       cout << endl
//          << "Deleted -> " << element << endl;
//       return (element);
//     }
//   }

//   /**
//    * @brief Displays the elements of the Queue
//    *
//    * Prints the front index, all elements in the Queue, and the rear index.
//    * If the Queue is empty, prints a message indicating that.
//    */
//   void display() {
//     int i;
//     if (isEmpty()) {
//       cout << endl
//          << "Empty Queue" << endl;
//     } else {
//       cout << endl
//          << "Front index-> " << front;
//       cout << endl
//          << "Items -> ";
//       for (i = front; i <= rear; i++)
//         cout << items[i] << ", ";
//       cout << endl
//          << "Rear index-> " << rear << endl;
//     }
//   }
// };

// int main() {
//   Queue q;

//   //deQueue is not possible on empty queue
//   q.deQueue();

//   //enQueue 5 elements
//   q.enQueue(1);
//   q.enQueue(2);
//   q.enQueue(3789);
//   q.enQueue(4);
//   q.enQueue(5);

//   // 6th element can't be added to because the queue is full
//   q.enQueue(6);

//   q.display();

//   //deQueue removes element entered first i.e. 1
//   q.deQueue();

//   //Now we have just 4 elements
//   q.display();

//   return 0;
// }


// #include <iostream>
// #include <vector>

// using namespace std;

// vector<int> twoSum(const vector<int>& nums, int target) {
//     for (int i = 0; i < nums.size(); ++i) {
//         for (int j = i + 1; j < nums.size(); ++j) {
//             if (nums[i] + nums[j] == target) {
//                 return {i, j};
//             }
//         }
//     }
//     return {}; // Should never be reached if there is exactly one solution
// }

// int main() {
//     vector<int> nums = {2, 7, 11, 15};
//     int target = 9;
//     vector<int> result = twoSum(nums, target);

//     cout << "Output: [" << result[0] << "," << result[1] << "]" << endl;
//     return 0;
// }
// #include <iostream>
// #include <vector>

// using namespace std;

// vector<int> twoSum(const vector<int>& nums, int target) {
//     for (int i = 0; i < nums.size(); ++i) {
//         for (int j = i + 1; j < nums.size(); ++j) {
//             if (nums[i] + nums[j] == target) {
//                 return {i, j};
//             }
//         }
//     }
//     return {}; // Should never be reached if there is exactly one solution
// }

// int main() {
//     vector<int> nums ;
//     int num;
//     cout<<"How many numbers you want to enter: "<<endl;
//     cin>>num;
//     cout<<"Enter numbers:"<<endl;
//     for (int i=0;i<num;i++){
//      nums.push_back(i);
//     }
//     int target;
//     cout<<"What is target:"<<endl;
//     cin>>target;
//     vector<int> result = twoSum(nums, target);

//     cout << "Output: [" << result[0] << "," << result[1] << "]" << endl;
//     return 0;
// }
#include <iostream>
#include <string>

using namespace std;

//  bool isPalindrome(int x) {
//     // Negative numbers are not palindromes
//     if (x < 0) return false;

//     // Convert the integer to a string
//     string str = to_string(x);

//     // Manually compare characters from the beginning and the end of the string
//     int n = str.size();
//     for (int i = 0; i < n / 2; ++i) {
//         if (str[i] != str[n - 1 - i]) {
//             return false;
//         }
//     }
//     return true;
// }

// int main() {
//     int x1 = 121;
//     int x2 = -121;
//     cout<<"guhij";
//     cin>>x1;
    
//     cout << "Input: " << x1 << "\nOutput: " << (isPalindrome(x1) ? "true" : "false") << endl;
//     cout << "Input: " << x2 << "\nOutput: " << (isPalindrome(x2) ? "true" : "false") << endl;
    
//     return 0;
// }

int main(){
    for (long int h=0;h<100000000000;h++){
        cout<<h<<endl;
    }
}



















































































































































































































































































































































