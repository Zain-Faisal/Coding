#include<iostream>
using namespace std;
class Complex{
public:
  double real;
  double imaginary;

Complex(){
    real=0;
    imaginary=0;
}
Complex(double real,double imaginary){
    this->real=real;
    this->imaginary=imaginary;
}
void Show(){
    cout<<real<<" + "<<imaginary<<"i"<<endl;
}
Complex operator +(Complex c){
    Complex temp;
    temp.real=real+c.real;
    temp.imaginary=imaginary+c.imaginary;
    return temp;
}
};

int main(){
    Complex c1(45,65);
    Complex c2=c1;
    Complex c3=c1+c2;
    
    c3.Show();
}

