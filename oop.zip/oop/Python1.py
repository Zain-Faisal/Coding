
# print("hello world")
# nums = [3,0,1]
# length = len(nums)
# nums.sort()
# new =[]
# value =1
# for i in range(0,length):
#    new.append(i)

# for value in new:
#      if value not in nums:
#             print(value)
nums=[0,1,0,3,12]
nums.sort()
new = []
for c in nums:
    if c != 0:
        new.append(c)      
for i in range(0,len(nums)):
    if nums[i]==0:
        new.append(0)

nums =[]
nums = new[:]
print(nums)

for 