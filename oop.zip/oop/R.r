na=2
print(na)
print (na+90)

first <- 45.6
second <- 78.9
print(first+second+89)
#install.packages("palmerpenguins")
#library("lubridate")
#library("tidyverse")
now()