// #include <iostream>
// #include <vector>

// using namespace std;

// int removeElement(vector<int>& nums, int val) {
//     int k = 0;  // `k` will be the count of elements not equal to `val`

//     // Iterate through the array
//     for (int i = 0; i < nums.size(); ++i) {
//         if (nums[i] != val) {
//             // Place the non-val element at index `k`
//             nums[k] = nums[i];
//             ++k;  // Increment the count of non-val elements
//         }
//     }

//     return k;  // Return the count of non-val elements
// }

// int main() {
//     vector<int> nums = {0, 1, 2, 2, 3, 0, 4, 2};
//     int val = 2;

//     int k = removeElement(nums, val);

//     // Print the first k elements of the array
//     cout << "The first " << k << " elements are: ";
//     for (int i = 0; i < k; ++i) {
//         cout << nums[i] << " ";
//     }
//     cout << endl;

//     return 0;
// }
#include<iostream>
#include<vector>
using namespace std;

    int removeDuplicates(vector<int> nums) {
        if (nums.empty()) {
            return 0;
        }

        int slow = 0;
        for (int fast = 1; fast < nums.size(); fast++) {
            if (nums[slow] != nums[fast]) {
                slow++;
                nums[slow] = nums[fast];
            }
        }
        for(int i=0;i<nums.size();i++){
            cout<<nums[i]<<", ";
        }
        cout<<endl;
        return slow + 1;
    }

int main(){
     
     vector<int>n{1,1,2};
     cout<<removeDuplicates(n);
     return 0;

}