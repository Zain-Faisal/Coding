print("def")
lists=[23,67,90,6778,899]
for list in lists:
    print(list)
def a(*i):
    result=0
    for o in i:
        result+=o
    return result
print(a(45,35,34,23,55))

# print("you are not a good man")
# ol=[89,23,243,24]
# def ma(*args):
#     result =0
#     for ors in ol:
#         result+=ors
#     return result
# print("Result: ",ma(78,45,23,12,34,45,45,34,34,23))
# class vehicle:
#     def __init__(self,model,name):
#         self.name=name
#         self.model=model
#     def a(name):
#         print("Name: ",name)
# vehilcle= print(a(2234))
# vehicle.a("zain")
# print("hio")
# o=input()
# print(o)
import numpy as np
s=np.array([43,243,23,2323,223,23])
print("Mean: ",np.mean(s))