fun main(args : Array<String>){
    val d :Int
    var a :Long
    a=0
    var ok=if (a<0){
        println("negative number")
    }
    else if(a>0) {
        println("positive number")
    }
    else{
        println("zero value")
    }
    for (i in 1..5){
        println("hello World!")
    }

   println("$ok")
   
    val numbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    val sumOfEvenNumbers = numbers.filter { it % 2 == 0 }.sum()
    println("Sum of even numbers: $sumOfEvenNumbers")

    // Create a map of numbers to their squares using a for comprehension
    val squares = numbers.map { it * it }
    println("Squares: $squares")

    // Find the first number greater than 5 using a sequence and a takeWhile
    val firstNumberGreaterThan5 = numbers.asSequence().takeWhile { it <= 5 }.lastOrNull()
    println("First number greater than 5: $firstNumberGreaterThan5")

    // Group numbers by their parity and sum them using a groupingBy and a fold
    val groupedSums = numbers.groupingBy { it % 2 == 0 }.fold(0) { acc, element -> acc + element }
    println("Grouped sums: $groupedSums")

    // Generate a sequence of Fibonacci numbers using a recursive lambda
    fun fibonacciSequence(): Sequence<Int> = sequence {
        var a = 0
        var b = 1
        yield(a)
        yield(b)
        while (true) {
            val next = a + b
            yield(next)
            a = b
            b = next
        }
    

    // Take the first 10 Fibonacci numbers
    val fibonacciNumbers = fibonacciSequence().take(10).toList()
    println("Fibonacci numbers: $fibonacciNumbers")
}
   
}
