





import flask

app =flask.Flask(__name__)

@app.route('/')
def index():
     
     print("<b>My Application</b>")
     print("<i> Testing !</i>")
     return "<h1> GENERAL </h1>"


if __name__ == '__main__':
    app.run(debug=True)