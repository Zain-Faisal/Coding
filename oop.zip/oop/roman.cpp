// #include<iostream>
// using namespace std;
// class Solution {
// public:
//     int romanToInt(string s) {
//         int k=s.length();
//         int result=0;
//         for(int i=0;i<k;i++){
//            if (s[i]=='I'){
//                 result+=1;
//             }
//             else if(s[i]=='V'){
//                 result+=5;
//             }
//             else if(s[i]=='X'){
//                 result=result+10;
//             }
//             else if(s[i]=='C'){
//                 result=result+100;
//             }
//             else if(s[i]=='M'){
//                 result=+1000;
//             }
//             else if(s[i]=='D'){
//                 result=result+500;
//             }
//             else if(s[i]=='L'){
//                 result+=50;
//             }
            
//         }
//    return result; }
// };
// int main(){

//     string h;
//     cout<<"enter roman"<<endl;
//     cin>>h;
//     Solution so;
//     cout<< so.romanToInt(h);
// }
#include <iostream>
#include <string>

using namespace std;

int romanToInt(const string& s) {
    int total = 0;
    int prevValue = 0;

    for (int i = s.size() - 1; i >= 0; --i) {
        int currentValue;

        switch (s[i]) {
            case 'I':
                currentValue = 1;
                break;
            case 'V':
                currentValue = 5;
                break;
            case 'X':
                currentValue = 10;
                break;
            case 'L':
                currentValue = 50;
                break;
            case 'C':
                currentValue = 100;
                break;
            case 'D':
                currentValue = 500;
                break;
            case 'M':
                currentValue = 1000;
                break;
            default:
                currentValue = 0;
                break;
        }

        if (currentValue < prevValue) {
            total -= currentValue;
        } else {
            total += currentValue;
        }
        prevValue = currentValue;
    }

    return total;
}

int main() {
    string s;
    cout << "Enter a Roman numeral: ";
    cin >> s;

    int result = romanToInt(s);
    cout << "The integer value is: " << result << endl;

    return 0;
}
