#include<iostream>
#include<cmath>
using namespace std;
int main(){
   long double choice;
    cout<<"Enter the number:"<<endl;
    cin>>choice;
    int choice1;
    cout<<"Enter 1 if you want square and enter 2 if you want square root:"<<endl;
    cin>>choice1;
    
    switch(choice1){
        case 1:
          cout<<"Square of "<<choice<<" is: "<<choice*choice<<endl;
          break;
        case 2:
          cout<<"Squar root of "<<choice<<" is: "<<sqrt(choice)<<endl;
          break;
        default:
         cout<<"Invalid input"<<endl;
       
    }
}