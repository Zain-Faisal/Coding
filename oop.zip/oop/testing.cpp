#include<iostream>
using namespace std;
struct Phone_node{
    string phone;
    string name;
    Phone_node *next;
};
class Phone_List{
    public:
    Phone_node *head;
    Phone_List();
    void print();
    void insert_at_beggining(string ,string);
    void insert_at_end(string,string);
};
Phone_List::Phone_List(){
    head = NULL;
}

void Phone_List::insert_at_beggining(string name,string phone){
        Phone_node * current = new Phone_node();
        current->name = name;
        current->phone = phone;
        current->next = head;
        head = current;
        }
void Phone_List::print(){
    Phone_node* current = head;
    cout<<"Name    Phone No"<<endl;
    while(current != NULL){
        cout<<current->name<<"    "<<current->phone<<endl;
        current = current->next;
    }
}
void Phone_List::insert_at_end(string name,string phone){
    Phone_node* newcontact = new Phone_node();
    newcontact->name = name;
    newcontact->phone = phone;
    newcontact->next = NULL;

    if(head == NULL){
        head = newcontact;
    }
    else{
        Phone_node* current = head;
        while(current->next != NULL){
            current = current->next;
        }
        current->next = newcontact;
    }
}

int main(){
    Phone_List p1;
    p1.insert_at_beggining("Zain","03091754514");
    p1.insert_at_beggining("Umer","03214569856");
    p1.insert_at_end("Talha","03569654128");
    p1.print();
    return 0;

}